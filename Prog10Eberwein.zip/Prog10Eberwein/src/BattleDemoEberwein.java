/**
 * @author Eberwein <br>
 * 
 * Prog 10<br>
 * Due: May 17th, before 9:00 a.m
 * 
 * Purpose: The purpose of this program is to play war. <br>
 * 
 * Input: The file name. <br>
 * 
 * Outputs: The battle summary which includes: how many cards the game started with, how many plays in the game, if there was a clear winner, how many cards each player ended with, and who the winner was. <br>
 * 
 * Certification of Authenticity: <br>
 * I certify that this lab is entirely my own work, but I discussed it with James Jenkins of the Marist Programming Lab.<br>
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class BattleDemoEberwein 
{

	//declare keyboard
	static Scanner keyboard = new Scanner(System.in);
	public static void main(String[] args)
	{
		
		//initialize variables
		StackEberwein playDeckOne = new StackEberwein();
		StackEberwein playDeckTwo = new StackEberwein();
		StackEberwein discardDeckOne = new StackEberwein();
		StackEberwein discardDeckTwo = new StackEberwein();
		int deckOneInitialTotal = 0;
		int deckTwoInitialTotal = 0;
		int deckOneFinalTotal = 0;
		int deckTwoFinalTotal = 0;
		int numPlays = 0;
		
		System.out.println("Welcome to my Program.");
		System.out.println("This program will ask for a file input of shuffled cards and deal them to two players.");
		System.out.println("The game War will be played with these cards.");
		System.out.println();
		
		//deal the cards
		dealCards(playDeckOne, playDeckTwo);
		
		//count the cards to see how many each player start with
		deckOneInitialTotal = countCards(playDeckOne);
		deckTwoInitialTotal = countCards(playDeckTwo);
		
		while((!playDeckOne.isEmpty())&&(!playDeckTwo.isEmpty())&&(numPlays<1000))
		{
			//play the cards, determine winner, and push cards to winner's discard pile
			play(playDeckOne, playDeckTwo, discardDeckOne, discardDeckTwo);
		
		
			//copy the discard deck into play deck if the play deck is empty
			if(playDeckOne.isEmpty())
				copy(playDeckOne, discardDeckOne);
			
			if(playDeckTwo.isEmpty())
				copy(playDeckTwo, discardDeckTwo);
			
			numPlays++;
		
		}//while
		
		
		deckOneFinalTotal = countCards(playDeckOne)+countCards(discardDeckOne);
		deckTwoFinalTotal = countCards(playDeckTwo)+countCards(discardDeckTwo);
		
		printResults(deckOneInitialTotal, deckTwoInitialTotal, deckOneFinalTotal, deckTwoFinalTotal, numPlays);
		
		
		keyboard.close();
		}//main
		
		
	
		/**
		 * The method will deal cards into the play stacks of the users
		 * @param playOne the play stack for player one
		 * @param playTwo the play stack for player two
		 */
		public static void dealCards(StackEberwein playOne, StackEberwein playTwo)
		{
			//initialize variables
			String fileName = null;
			File inputFile = null;
			CardEberwein firstFileItem = null;
			CardEberwein secondFileItem = null;
			String firstCardName;
			String secondCardName;
			int firstCardNumber = 0;
			int secondCardNumber = 0;
			int cards=0;
			
			try
			{
				System.out.println("Enter the file name: ");
				fileName = keyboard.next();
				inputFile = new File(fileName);
				
				Scanner input = new Scanner(inputFile);

				while(input.hasNext()&&(cards<52))
				{
					String cardNumber = input.next();
					firstCardNumber = Integer.parseInt(cardNumber);
					firstCardName = input.next();
					firstFileItem = new CardEberwein(firstCardNumber, firstCardName);
					playOne.push(firstFileItem);
					cards++;
					
					if(input.hasNext())
					{
						secondCardNumber = input.nextInt();
						secondCardName = input.next();
						secondFileItem = new CardEberwein(secondCardNumber, secondCardName);
						playTwo.push(secondFileItem);
						cards++;
					}//if
					
				}//for
				
				input.close();
			}//try
			
			catch(FileNotFoundException ex)
			{
				System.out.println("Failed to find file: " + inputFile.getAbsolutePath());
				System.out.println();
				
			}//catch
			
			catch(InputMismatchException ex)
			{
				System.out.println("Type mismatch for the number I just tried to read.");
				System.out.println(ex.getMessage());
				System.out.println();
				
			}//catch
			
			catch(NumberFormatException ex)
			{
				System.out.println("Failed to convert String text into an integer value.");
				System.out.println(ex.getMessage());
				System.out.println();
				
			}//catch
			
			catch(NullPointerException ex)
			{
				System.out.println("Null pointer exception.");
				System.out.println(ex.getMessage());
				System.out.println();
				
			}//catch
			
			catch(Exception ex)
			{
			//catchall
			System.out.println("Something went wrong");
			System.out.println();
			ex.printStackTrace();
			
			}//catch
		}//dealCards
		
		
		
		/**
		 * The method will play the cards from the play stacks of the two players
		 * @param playOne the play deck of player one
		 * @param playTwo the play deck of player two
		 * @param discardOne the discard deck of player one
		 * @param discardTwo the discard deck of player two
		 */
		public static void play(StackEberwein playOne, StackEberwein playTwo, StackEberwein discardOne, StackEberwein discardTwo)
		{
			CardEberwein playerOneCard = null;
			CardEberwein playerTwoCard = null;
			
			playerOneCard = playOne.pop();
			playerTwoCard = playTwo.pop();
			
			//compare the cards and give cards to winner
			compare(playerOneCard, playerTwoCard, discardOne, discardTwo);

		}//play
		
		
		
		/**
		 * The method will compare cards from each player's decks and push them to the discard deck accordingly
		 * @param cardOne the card being compared from player one's deck
		 * @param cardTwo the card being compared from player two's deck
		 * @param discardPileOne player one's discard pile
		 * @param discardPileTwo player two's discard pile
		 */
		public static void compare(CardEberwein cardOne, CardEberwein cardTwo, StackEberwein discardPileOne, StackEberwein discardPileTwo)
		{
			
			if (cardOne.getCardNum()>cardTwo.getCardNum())
			{
				discardPileOne.push(cardOne);
				discardPileOne.push(cardTwo);
			}//if
			
			else if(cardTwo.getCardNum()>cardOne.getCardNum())
			{
				discardPileTwo.push(cardTwo);
				discardPileTwo.push(cardOne);
			}//else if
			
			else
			{
				if(cardOne.getCardSuit().compareToIgnoreCase(cardTwo.getCardSuit())==0)
				{
					discardPileOne.push(cardOne);
					discardPileTwo.push(cardTwo);
				}//if
				
				else if (cardOne.getCardSuit().compareToIgnoreCase("Spades")==0)
				{
					discardPileOne.push(cardOne);
					discardPileOne.push(cardTwo);
				}//if
				
				else if (cardTwo.getCardSuit().compareToIgnoreCase("Spades")==0)
				{
					discardPileTwo.push(cardTwo);
					discardPileTwo.push(cardOne);
				}//else if
				
				else if (cardOne.getCardSuit().compareToIgnoreCase("Hearts")==0)
				{
					discardPileOne.push(cardOne);
					discardPileOne.push(cardTwo);
				}//else if
				
				else if (cardTwo.getCardSuit().compareToIgnoreCase("Hearts")==0)
				{
					discardPileTwo.push(cardTwo);
					discardPileTwo.push(cardOne);
				}//else if
				
				else if (cardOne.getCardSuit().compareToIgnoreCase("Diamonds")==0)
				{
					discardPileOne.push(cardOne);
					discardPileOne.push(cardTwo);
				}//else if
				
				else if (cardTwo.getCardSuit().compareToIgnoreCase("Diamonds")==0)
				{
					discardPileTwo.push(cardTwo);
					discardPileTwo.push(cardOne);
				}//else if
				
			}//else
						
		}//compare
			
		
		
		/**
		 * The method copies the discard deck into the play deck, in the same order it was in the discard deck
		 * @param thePlayingDeck the play deck of the player 
		 * @param theDiscardingDeck the discard deck of the player
		 */
		public static void copy(StackEberwein thePlayingDeck, StackEberwein theDiscardingDeck)
		{
			CardEberwein theValue = null;
			StackEberwein temp = new StackEberwein();
			
			while(!theDiscardingDeck.isEmpty())
			{
				theValue = theDiscardingDeck.pop();
				temp.push(theValue);
			}//while
			
			while(!temp.isEmpty())
			{
				theValue = temp.pop();
				thePlayingDeck.push(theValue);
			}//while
			
		}//copy
		
		
		
		/**
		 * The method will count the cards in the deck
		 * @param theStack the deck that the cards are being counted from
		 * @return the number of cards in the deck
		 */
		public static int countCards(StackEberwein theStack)
		{
			int total = 0;
			CardEberwein theValue = null;
			StackEberwein temp = new StackEberwein();
			
			while(!theStack.isEmpty())
			{
				theValue = theStack.pop();
				temp.push(theValue);
				total++;
			}//while
			
			while(!temp.isEmpty())
			{
				theValue = temp.pop();
				theStack.push(theValue);
			}//while
			
			return total;
			
		}//countCards
		
		
		
		/**
		 * The method will print the battle summary
		 * @param deckOneStart the number of cards deck one started with
		 * @param deckTwoStart the number of cards deck two started with
		 * @param deckOneEnd the number of cards deck one ended with
		 * @param deckTwoEnd the number of cards deck two ended with
		 * @param plays the number of plays that occurred during the battle
		 */
		public static void printResults(int deckOneStart, int deckTwoStart, int deckOneEnd, int deckTwoEnd, int plays)
		{
			int totalCards = deckOneStart+deckTwoStart;
			
			System.out.println();
			System.out.println("Battle Card Game Summary:");
			System.out.println();
			
			if(totalCards==1)
				System.out.println("The game started with " + totalCards + " card.");
			else
				System.out.println("The game started with " + totalCards + " cards.");
			
			if(plays==1)
				System.out.println("There was " + plays + " play in the game.");
			else
				System.out.println("There were " + plays + " plays in the game.");
			
			if (deckOneEnd-deckTwoEnd != 0)
				System.out.println("The game ended with a clear winner.");
			
			else
				System.out.println("The game did not end with a clear winner.");
			
			if(deckOneEnd==1)
				System.out.println("Player 1 ended with " + deckOneEnd + " card.");
			else
				System.out.println("Player 1 ended with " + deckOneEnd + " cards.");
			
			if(deckTwoEnd==1)
				System.out.println("Player 2 ended with " + deckTwoEnd + " card.");
			else
				System.out.println("Player 2 ended with " + deckTwoEnd + " cards.");
			
			if (deckOneEnd>deckTwoEnd)
				System.out.println("The winner was Player 1.");
			
			else if (deckTwoEnd>deckOneEnd)
				System.out.println("The winner was Player 2.");
			
			else
				System.out.println("There was a tie.");
			
		}//printResults
		

}//BattleDemoEberwein
