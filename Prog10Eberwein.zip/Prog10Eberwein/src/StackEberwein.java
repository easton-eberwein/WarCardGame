/**
 * 
 * @author Easton <br>
 * 
 * This is the class definition for StackEberwein
 *
 */
public class StackEberwein 
{
	/**
	 * Instance variable for the top node
	 */
	private NodeEberwein myTop;
	
	/**
	 * The default constructor for StackEberwein
	 */
	public StackEberwein()
	{ myTop = null; }//StackEberwein
	
	/**
	 * The method will push a card onto a stack
	 * @param thing an incoming card item
	 * @return if the card was pushed or not
	 */
	public boolean push(CardEberwein thing)
	{
		boolean ans = false;
		NodeEberwein newGuy = null;
		if(!isFull())
		{
			ans = true;
			newGuy = new NodeEberwein();
			newGuy.setData(thing);;
			newGuy.setNext(myTop);;
			myTop = newGuy;
		}//if
		return ans;
	}//push
	
	/**
	 * The method will pop a card off a stack
	 * @return the card that was popped
	 */
	public CardEberwein pop()
	{
		CardEberwein ans = null;
		if(!isEmpty())
		{
			ans = myTop.getData();
			myTop = myTop.getNext();
			
		}//if
		return ans;
	}//pop
	
	/**
	 * The method will determine if the stack is empty
	 * @return if the stack is empty or not
	 */
	public boolean isEmpty()
	{
		boolean ans = false;
		if(myTop == null)
			ans = true;
		
		return ans;
	}//isEmpty
	
	/**
	 * The method will determine if the stack is full
	 * @return if the stack is full or not
	 */
	public boolean isFull()
	{
		return false;
	}//isFull
	
}//StackEberwein
