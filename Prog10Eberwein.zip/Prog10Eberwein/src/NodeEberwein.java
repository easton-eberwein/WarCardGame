/**
 * 
 * @author Easton <br>
 * 
 * This is the class definition for NodeEberwein
 *
 */
public class NodeEberwein 
{
	/**
	 * Instance variable for the node's data
	 */
	private CardEberwein myData;

	/**
	 * Instance variable for the node's next data
	 */
	private NodeEberwein myNext;
	
	/**
	 * The default constructor for NodeEberwein
	 */
	public NodeEberwein()
	{
		myNext = null;
		myData = null;
	}//NodeEberwein
	
	public NodeEberwein(CardEberwein newData)
	{
		myData = newData;
		myNext = null;
	}//NodeEberwein
	
	/**
	 * The getter for the node's data
	 * @return The data of this node
	 */
	public CardEberwein getData()
	{ return myData; }//getData
	
	/**
	 * The setter for the node's data 
	 * @param newData The incoming data of this node
	 */
	public void setData(CardEberwein newData)
	{ myData = newData; }//setData
	
	/**
	 * The getter for the next node
	 * @return The next node
	 */
	public NodeEberwein getNext()
	{ return myNext; }//getNext
	
	/**
	 * The setter for the next node
	 * @param newNext The new next node
	 */
	public void setNext(NodeEberwein newNext)
	{ myNext = newNext; }//setNext


}//NodeEberwein
