/**
 * 
 * @author Easton <br>
 * 
 * This is the class definition for CardEberwein
 *
 */
public class CardEberwein 
{
	/**
	 * Instance variable for the card's suit
	 */
	private String myCardSuit;
	
	/**
	 * Instance variable for the card's number
	 */
	private int myCardNum;
	
	
	/**
	 * The default constructor for CardEberwein
	 */
	public CardEberwein()
	{
		myCardSuit = "none";
		myCardNum = 0;
	}//CardEberwein
	
	
	public CardEberwein(int newCardNum, String newCardSuit)
	{
		myCardSuit = newCardSuit;
		myCardNum = newCardNum;
	}//CardEberwein
	
	
	/**
	 * The setter for the card's suit
	 * @param newCardSuit the suit of the new card
	 */
	public void setCardSuit(String newCardSuit)
	{ myCardSuit = newCardSuit; }//setCardSuit
	
	/**
	 * The setter for the card's number
	 * @param newCardNum the number of the new card
	 */
	public void setCardNum(int newCardNum)
	{ myCardNum = newCardNum; }//setCardNum
	
	/**
	 * The getter for the card's suit
	 * @return the suit of the card
	 */
	public String getCardSuit()
	{ return myCardSuit; }//getCardSuit
	
	/**
	 * The getter for the card's number
	 * @return the number of the card
	 */
	public int getCardNum()
	{ return myCardNum; }//getCardNum

}//CardEberwein
